#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

        /// ######## DEFINE ######## ///
#define COL 1200
#define LIN 700
#define T_CASE 50

        /// ######## STRUCTURES ######## ///
typedef struct joueur{
    int pv;             //nombre de PV du joueur � savoir 20
    int pa;             //nombre de PA du joueur
    int num_joueur;     //le num�ro du joueur
    int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
    int pos_x;
    int pos_y;
}t_joueur;


/// ############################# MENU ########################################## ///

int prog_menu()
{
    //condition pour sortir des boucles du menu
    int condition=0;
    int nbjoueurs;//pour savoir combien de joueurs vont s'affronter
    BITMAP *decor;       // declaration de tous les bitmap qu'on utilise dans ce sous programme
    BITMAP *selectjoueur;
    BITMAP *page;
    BITMAP *regles;
    BITMAP *choixjoueur;
    BITMAP *reglesDuJeu;
    reglesDuJeu=load_bitmap("reglesjeu.bmp",NULL);
    regles=load_bitmap("reglesdujeu.bmp",NULL);
    decor=load_bitmap("garde.bmp",NULL);
    choixjoueur=load_bitmap("choixjoueur.bmp",NULL);
    selectjoueur=load_bitmap("selectionnerjoueur.bmp",NULL);
    if (!decor || !choixjoueur || !selectjoueur || !regles || !reglesDuJeu)
    {//condition pour savoir si tt s'est bien ouvert ou pas
        allegro_message("pas pu trouver l'image");
        exit(EXIT_FAILURE);
    }
    page = create_bitmap(SCREEN_W,SCREEN_H);//creation d'un buffer


///-------------------------------------------affichage de l'ecran d'accueil----------------------------------------------------
///-----------------------------------------------------------------------------------------------------------------------------
    while (condition==0)
    {
        clear_bitmap(page);//on efface le buffer
        blit(decor,page,0,0,0,0,SCREEN_W,SCREEN_H); //puis on reaffiche l'image sur le buffer
        blit(selectjoueur,page,0,0,850,400,SCREEN_W,SCREEN_H);
        blit(regles,page,0,0,100,400,SCREEN_W,SCREEN_H);
        //on affiche le buffer a l'ecran avec tt ce qu'il y a dessus
        blit(page,screen,0,0,0,0,SCREEN_W,SCREEN_H);
        if(mouse_b)
        {
            //on va lire la couleur a l'endroit ou on clique
            //en fonction de la couleur ca va soit ouvrir les regles du jeu soit le choix des personnages
            int pixel, color;
            pixel = getpixel(page,mouse_x,mouse_y);//fonction pour lire un pixel sur l'ecran
            color=makecol(getr(pixel),getg(pixel),getb(pixel));
            int couleur1=makecol(255,255,255);//les couleurs pour l'option 1
            int couleur2=makecol(0,165,230);
            if(color==couleur1 || color==couleur2)
            {
                condition=1;//si l'utilisateur clique pour l'option 1 la condition vaut 1
            }               //et une nouvelle boucle va s'ouvrir avec ce qu'il a demande
            int couleur3=makecol(255,254,255);//couleurs pour l'option 2
            int couleur4=makecol(0,166,230);
            if(color==couleur3 || color==couleur4)
            {
                condition=2;//si l'utilisateur clique pour l'option 2 la condition vaut 2
            }               //et une nouvelle boucle va s'ouvrir avec ce qu'il a demande
        }
    }


///----------------------------------------------------affichage des regles du jeu-----------------------------------------------------
    int conditionbis=0;//condition pour afficher les regles du jeu
    while (condition==2)
    {
        while(conditionbis==0)
        {
            clear_bitmap(page);
            blit(reglesDuJeu,page,0,0,0,0,SCREEN_W,SCREEN_H);
            rectfill(page,850,20,1080,70,makecol(255,255,255));//affichage d'un rectangle pour revenir au menu et sortir de la boucle des regles du jeu
            textprintf_centre_ex(page, font, 965, 40, makecol(0,0,255), -1,"CLIQUEZ ICI POUR CONTINUER");//texte pour indiquer la sortie
            blit(page,screen,0,0,0,0,SCREEN_W,SCREEN_H);//affichage du buffer
            if(mouse_b)
            {//condition quand le joeur clique sur le rectangle de la sortie des regles du jeu
                if(850<mouse_x && mouse_x<1080 && 20<mouse_y && mouse_y<70)
                {
                    conditionbis=1;//on stop la boucle
                    condition=0;
                    prog_menu();//rappelle du sous programme du menu pour continuer la partie
                }
            }
        }
    }


///-----------------------------------affichage du choix nombres de joueurs------------------------------------------
    while (condition==1)
    {
        clear_bitmap(page);//meme principe que pour la boucle precedante pour l'affichage et la detection de la couleur du pixel
        blit(choixjoueur,page,0,0,0,0,SCREEN_W,SCREEN_H);
        blit(page,screen,0,0,0,0,SCREEN_W,SCREEN_H);

        if(mouse_b)//condition de choix de l'utilisateur
        {
            int pixel, color;
            pixel = getpixel(page,mouse_x,mouse_y);
            color=makecol(getr(pixel),getg(pixel),getb(pixel));
            int couleur1=makecol(255,0,0);
            int couleur2=makecol(254,0,0);
            int couleur3=makecol(253,0,0);
            rest(50);
            if(color==couleur1)//si couleur 1 alors l'utilisateur a choisi 2 joueur
            {
                nbjoueurs=2;
                condition=3;//pour stopper cette boucle while et en ouvrir une autre
            }
            if(color==couleur2)//si couleur 2 alors l'utilisateur a choisi 3 joueur
            {
                nbjoueurs=3;
                condition=3;//pour stopper cette boucle while et en ouvrir une autre

            }
            if(color==couleur3)//si couleur 3 alors l'utilisateur a choisi 4 joueur
            {
                nbjoueurs=4;
                condition=3;//pour stopper cette boucle while et en ouvrir une autre
            }
        }
    }
return nbjoueurs;
}


int prog_choix_des_classes(t_joueur *tableau_joueur, int nbjoueurs)
{
    BITMAP *classe1;
    BITMAP *classe2;
    BITMAP *classe3;
    BITMAP *classe4;
    BITMAP *choixclasse;
    BITMAP *stat;
    BITMAP *page;
    page=create_bitmap(SCREEN_W,SCREEN_H);
    stat=load_bitmap("stats.bmp",NULL);
    choixclasse=load_bitmap("choixclasse.bmp",NULL);
    classe1=load_bitmap("classe1.bmp",NULL);//les bitmaps sont ensuite assimile a des photos
    classe2=load_bitmap("classe2.bmp",NULL);
    classe3=load_bitmap("classe3.bmp",NULL);
    classe4=load_bitmap("classe4.bmp",NULL);
    if (!classe1 || !classe2 || !classe3 || !classe4 || !choixclasse || !stat)
    {//condition pour savoir si tt s'est bien ouvert ou pas
        allegro_message("pas pu trouver l'image");
        exit(EXIT_FAILURE);
    }
///----------------------------------------affichage du choix des classes-------------------------------------------------
    int condition=0;
    int cond=0;
    while(cond!=nbjoueurs)
    {
        condition=0;
        while (condition==0)
        {
            rest(100);//on met un delay pour ne pas que lorsque que le premier joueur choisi sa classe cela clique aussi pour le joueur suivant
            clear_bitmap(page);//on efface le bitmap pour reaficher ce qu'on a besoin ici dessus
            blit(choixclasse,page,0,0,0,0,SCREEN_W,SCREEN_H);//affiche photo de fond
            blit(classe1,page,0,0,100,350,SCREEN_W,SCREEN_H);//affichage photo des 4 classes disponible
            blit(classe2,page,0,0,325,350,SCREEN_W,SCREEN_H);
            blit(classe3,page,0,0,725,350,SCREEN_W,SCREEN_H);
            blit(classe4,page,0,0,950,350,SCREEN_W,SCREEN_H);
            blit(stat,page,0,0,525,400,SCREEN_W,SCREEN_H);//affichage option pour voir les statistiques
            textprintf_centre_ex(page, font, 600, 100, makecol(255,255,255), -1,"JOUEUR %d A VOUS DE CHOISIR VOTRE CLASSE",cond);//affichge du joueur
            if(mouse_b)                                                                                   //a qui s'est au tour de choisir sa classe
            {//condition pour savoir si le joueur clique quelque part (sur le choix d'une classe ou des statistiques)
                if(100<mouse_x && mouse_x<250 && 350<mouse_y && mouse_y<600)//coordonnees de la photo de la classe 1
                {
                    tableau_joueur[cond].classe_joueur=1;
                    condition=1;//condition sert ici a sortir de la boucle d'un joueur pour passer au joueur suivant s'il existe
                }//ou lancer la partie s'il n'y en a pas
                if(325<mouse_x && mouse_x<475 && 350<mouse_y && mouse_y<600)//coordonnees de la photo de la classe 2
                {
                    tableau_joueur[cond].classe_joueur=2;
                    condition=1;
                }
                if(725<mouse_x && mouse_x<875 && 350<mouse_y && mouse_y<600)//coordonnees de la photo de la classe 3
                {
                    tableau_joueur[cond].classe_joueur=3;
                    condition=1;
                }
                if(950<mouse_x && mouse_x<1100 && 350<mouse_y && mouse_y<600)//coordonnees de la photo de la classe 4
                {
                    tableau_joueur[cond].classe_joueur=4;
                    condition=1;
                }
                if(525<mouse_x && mouse_x<675 && 400<mouse_y && mouse_y<469)//coordonnes pour acceder aux statistiques des classes
                {
                    statistiquesDesClasses();//sous programme des statistiques des classes pour pouvoir y avoir acces pendant toute la partie
                }
            }
            blit(page,screen,0,0,0,0,SCREEN_W,SCREEN_H);//affichage du bitmap

        }
        cond=cond+1;
    }
}



int statistiquesDesClasses()
{
    BITMAP *imageStatistiques;
    imageStatistiques=load_bitmap("imageStat.bmp",NULL);
    if(!imageStatistiques)
    {//condition pour savoir si tt s'est bien ouvert ou pas
        allegro_message("pas pu trouver l'image");
        exit(EXIT_FAILURE);
    }
    int condition=0;
    while(condition==0)
    {
        blit(imageStatistiques,screen,0,0,0,0,SCREEN_W,SCREEN_H);
        if(mouse_b)
        {
            if(1050<mouse_x && mouse_x<1170 && 30<mouse_y && mouse_y<90)
            {
                condition=1;
    }}}}




int statistiquesDesClassesAvecPV(t_joueur *tableau_joueur, int nbjoueurs)
{
    BITMAP *imageStatistiques;
    BITMAP *page;
    page=create_bitmap(SCREEN_W,SCREEN_H);
    imageStatistiques=load_bitmap("imageStat.bmp",NULL);
    if(!imageStatistiques)
    {//condition pour savoir si tt s'est bien ouvert ou pas
        allegro_message("pas pu trouver l'image");
        exit(EXIT_FAILURE);
    }
    int condition=0;
    int i=0;
    int coordonnes;
    while(condition==0)
    {
        coordonnes=250;
        clear_bitmap(page);
        blit(imageStatistiques,page,0,0,0,0,SCREEN_W,SCREEN_H);
        for(i=0; i<nbjoueurs; i++)
        {
            if(tableau_joueur[i].classe_joueur==1)
            {
                textprintf_ex(page, font, 850, coordonnes, makecol(255,255,255), -1,"Joueur %d : MARIO : PV=%d, PA=%d",i+1,tableau_joueur[i].pv,tableau_joueur[i].pa);
            }
            if(tableau_joueur[i].classe_joueur==2)
            {
                textprintf_ex(page, font, 850, coordonnes, makecol(255,255,255), -1,"Joueur %d : BOWSER : PV=%d, PA=%d",i+1,tableau_joueur[i].pv,tableau_joueur[i].pa);
            }
            if(tableau_joueur[i].classe_joueur==3)
            {
                textprintf_ex(page, font, 850, coordonnes, makecol(255,255,255), -1,"Joueur %d : YOSHI : PV=%d, PA=%d",i+1,tableau_joueur[i].pv,tableau_joueur[i].pa);
            }
            if(tableau_joueur[i].classe_joueur==4)
            {
                textprintf_ex(page, font, 850, coordonnes, makecol(255,255,255), -1,"Joueur %d : TOAD : PV=%d, PA=%d",i+1,tableau_joueur[i].pv,tableau_joueur[i].pa);
            }
            coordonnes=coordonnes+30;
        }
        blit(page,screen,0,0,0,0,SCREEN_W,SCREEN_H);
        if(mouse_b)
        {
            if(1050<mouse_x && mouse_x<1170 && 30<mouse_y && mouse_y<90)
            {
                condition=1;
            }
        }
    }
}
