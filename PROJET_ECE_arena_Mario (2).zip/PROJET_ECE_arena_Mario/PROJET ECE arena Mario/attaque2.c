#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

        /// ######## DEFINE ######## ///
#define COL 1200
#define LIN 700
#define T_CASE 50

        /// ######## STRUCTURES ######## ///
typedef struct joueur{
    int pv;             //nombre de PV du joueur � savoir 20
    int pa;             //nombre de PA du joueur
    int num_joueur;     //le num�ro du joueur
    int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
    int pos_x;
    int pos_y;
}t_joueur;

typedef struct classe{
char nom_de_classe[30];
int tab_degats_attaques[5];     //tableau contenant les d�g�ts inflig�s par les attaques
int tab_PA_attaques[5];         //tableau contenant les c�uts des attaques
}t_classe;


///-------------------------------------Sous programme attaque-------------------------------------///
    ///////////////////////////////////////////////////////////////////////////////////
    //Le sous prog prend en param�tres:
    //
    //le num�ro du joueur qui joue (=1 si joueur 1, =3 si joueur 3 etc...)
    //la matrice: tabChose[20][10]
    //la classe
    //le tableau joueur
    //le num�ro de l'ttaque utilis�e (0: corps � corps, 1: sort n�1, 2: sort n�2 etc...
    ///////////////////////////////////////////////////////////////////////////////////
int attaque(int num_joueur, int tabChose[20][10], t_classe* classe, t_joueur* tableau_joueur, int numero_attaque)
{
    int couleur =getpixel(screen, mouse_x, mouse_y);             //On r�cupere la couleur du pixel
    int r =getr(couleur);   int g =getg(couleur);   int b =getb(couleur);//On la transforme en r g b
if((r ==255 && g ==0 && b ==0)){ //On test si souris dans zone verte
    int couleur_rouge = makecol(255, 0, 0);
    if(mouse_b & 1)//Test si clique gauche
    {
        //R�cup�ration de la position de la souris//
        int souris_lin = 0;
        int souris_col = 0;
        souris_lin =(mouse_y/50);
        souris_col =(mouse_x/50);
        ////////////////////////////////////////////

        int couleur_case = getpixel(screen , mouse_x, mouse_y);//R�cup�ration de la couleur de la case

        if(couleur_case == couleur_rouge)//Si la case est rouge (=case � port�e)
        {
            tableau_joueur[num_joueur].pa = tableau_joueur[num_joueur].pa - classe->tab_PA_attaques[numero_attaque];//L'attaquant perd des PA

            if(tabChose[souris_col][souris_lin] != 0)//Si pr�sence d'un joueur
                {
                    int victime = 0;
                    if(tabChose[souris_col][souris_lin] == 1) victime = 1;//Si pr�sence joueur 1
                    if(tabChose[souris_col][souris_lin] == 2) victime = 2;//Si pr�sence joueur 2
                    if(tabChose[souris_col][souris_lin] == 3) victime = 3;//Si pr�sence joueur 3
                    if(tabChose[souris_col][souris_lin] == 4) victime = 4;//Si pr�sence joueur 4

                    //Calcul de la proba d'�chec//
                    srand(time(NULL));
                    int proba_echec = rand()%12;
                    //////////////////////////////

                    if(proba_echec != 0)//Si l'attaque n'a pas �chou�
                    {
                        //Permet de g�n�rer al�atoirement le nb de d�g�ts inflig�s//
                        int pv_infliges = 0;
                        int pv_max = classe->tab_degats_attaques[numero_attaque] + 1;
                        int pv_min = classe->tab_degats_attaques[numero_attaque] - 1;
                        pv_infliges = pv_min + rand()%(pv_max-pv_min+1);
                        ////////////////////////////////////////////////////////////

                        tableau_joueur[victime].pv = tableau_joueur[victime].pv - pv_infliges;//Application des d�g�ts au joueur victime de l'attaque
                    }
                }

                else//Si l'attaque a �chou�e
                {
                    allegro_message("Quel dommage votre attaque a echoue");//Message d erreur
                }
        }

            else//Si case vide
            {
                allegro_message("Vous avez tire dans le vide");//Message d echec
            }
    }
}}
///-----------------------------------Fin Sous programme attaque-----------------------------------///
