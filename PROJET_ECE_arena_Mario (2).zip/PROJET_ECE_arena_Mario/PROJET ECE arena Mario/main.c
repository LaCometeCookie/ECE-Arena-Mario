#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

int EXE();


int main()
{
    EXE();

    allegro_exit();
    return 0;

} END_OF_MAIN();



