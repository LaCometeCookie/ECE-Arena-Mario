
#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

        /// ######## DEFINE ######## ///
#define COL 1200
#define LIN 700
#define T_CASE 50

        /// ######## STRUCTURES ######## ///
typedef struct joueur{
    int pv;             //nombre de PV du joueur � savoir 20
    int pa;             //nombre de PA du joueur
    int num_joueur;     //le num�ro du joueur
    int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
    int pos_x;
    int pos_y;
}t_joueur;

        /// ######## PROTOTYPES ######## ///
void affichageZoneVerte(int caseP_x, int caseP_y, int tabChose[20][10], BITMAP *buffer);
int creationPlateau(BITMAP *buffer, BITMAP *padMvmt, int souris_lin, int souris_col, int souris_gauche);


        /// ######## SOUS PROGRAMME ######## ///
void deplacements(BITMAP *tabMario,int dep, int dep_v2, int souris_gauche, int souris_lin, int souris_col,BITMAP *plateau, BITMAP *cache, BITMAP *buffer, BITMAP *sprite, BITMAP *padMvmt, t_joueur *tableau_joueur, int tabChose[20][10], int tour){

    if(souris_gauche ==1 && mouse_x >1002 && mouse_y >30 && mouse_y <230 && dep ==0){ //test si bouton dep cliqu�
        dep =1;
        dep_v2 =1;}

    //ON RECUP POSITION DU JOUEUR
    int caseJ_x = tableau_joueur[tour].pos_x;   int caseJ_y = tableau_joueur[tour].pos_y; // Case du joueur
    //int caseP_x =0;                             int caseP_y = caseJ_y -3; // CaseP = position du curseur pour tracer cases
    int caseP_x =0; int caseP_y =0;
    int couleur =0, r =0, g =0, b =0;
    int sx =(mouse_x/50), sy =(mouse_x/50);
    int posx =0, posy =0;



    while(dep ==1){            // Si bouton dep cliqu� -> test plus haut
        /// AFFICHAGE

        blit(plateau,buffer, 0,0,0,0, COL, LIN); //On affiche le plateau en premier

        caseP_x =caseJ_x;   caseP_y =caseJ_y; //Variables

        if(dep_v2 ==1){
            blit(plateau,buffer, 0,0,0,0, COL, LIN); //On affiche le plateau en premier
            affichageZoneVerte(caseP_x, caseP_y, tabChose, buffer);
            //draw_sprite(buffer, sprite, tableau_joueur[tour].pos_x *50, tableau_joueur[tour].pos_y *50);

            rest(20);
            blit(buffer,screen, 0,0,0,0, COL, LIN); //On affiche la grille verte � l'�cran
            blit(buffer, cache, 0,0,0,0, COL, LIN); //On affiche la grille verte dans une bitmap cache pour faire les tests
        }

        /// CHEMIN


        caseP_x =caseJ_x;   caseP_y =caseJ_y; //Reset des variables

        couleur =getpixel(cache, mouse_x, mouse_y);             //On r�cupere la couleur du pixel
        r =getr(couleur);   g =getg(couleur);   b =getb(couleur);//On la transforme en r g b

        if((r ==0 && g ==255 && b ==0)){ //On test si souris dans zone verte
            //blit(plateau,buffer, 0,0,0,0, COL, LIN); //On affiche le plateau en premier
            rest(20);
            sx =(mouse_x/50); sy =(mouse_y/50);
            posx =tableau_joueur[tour].pos_x;
            posy =tableau_joueur[tour].pos_y;
            caseP_x =tableau_joueur[tour].pos_x;
            caseP_y =tableau_joueur[tour].pos_y;

            dep_v2 =2;}
        else{
            dep_v2 =1;
        }


        if(dep_v2 ==2){
            //rectfill(buffer,0,0,1000,500, makecol(0,0,0));
            blit(plateau,buffer, 0,0,0,0, COL, LIN); //On affiche le plateau en premier
          for(int i =0; i <3; i++){
            if(sx >posx){
                caseP_x++;}
            else if(sx <posx){
                caseP_x--;}
             else if(sy >posy){
                caseP_y++;}
            else if(sy <posy){
                caseP_y--;}

            posx =caseP_x; posy =caseP_y;

            rectfill(buffer, (posx *50), (posy *50), ((posx*50) +50), ((posy*50) +50), makecol(0,255,150));
          }

        couleur =getpixel(buffer, mouse_x, mouse_y);             //On r�cupere la couleur du pixel
        r =getr(couleur);   g =getg(couleur);   b =getb(couleur);//On la transforme en r g b
        int var =mouse_b&1;

    /*rectfill(buffer, 1050, 400, 1200, 420, makecol(0,0,0));
    textprintf_ex(buffer, font, 1010, 400, makecol(255,255,255), -1, "r%d g%d b%d /clic: %d", r,g,b,var);*/

        if(var ==1){
            if(r ==0 && g ==255 && b ==150){
                //textprintf_ex(buffer, font, 1010, 500, makecol(255,255,255), -1, "COUCOU");

            /// DEPLACEMENT
            int num =tableau_joueur[tour].classe_joueur;

            tabChose[tableau_joueur[tour].pos_x][tableau_joueur[tour].pos_y] =0; // On reset l'obstacle
            tableau_joueur[tour].pos_x = (mouse_x/50);
            tableau_joueur[tour].pos_y = (mouse_y/50);
            tabChose[tableau_joueur[tour].pos_x][tableau_joueur[tour].pos_y] =tour; //On cr�e le nouveau obstacle

            dep =0; dep_v2 =0;
            }
        }
      }

    /// AFFICHAGE DU RESTE
    if(dep ==1){


    creationPlateau(buffer, padMvmt, (mouse_y/50), (mouse_x/50), souris_gauche); //Sous programme de cr�ation du plateau
    draw_sprite(buffer, sprite, tableau_joueur[tour].pos_x *50, tableau_joueur[tour].pos_y *50 -40);
    draw_sprite(buffer, tabMario, tableau_joueur[tour+1].pos_x *50, tableau_joueur[tour+1].pos_y *50 -40);
    blit(buffer,screen, 0,0,0,0, COL, LIN); //On termine par affiche le buffer
    }}
}



void affichageZoneVerte(int caseP_x, int caseP_y, int tabChose[20][10], BITMAP *buffer)
{
    if(tabChose[caseP_x][caseP_y-3] ==0 && (caseP_x <20) && (caseP_y-3 <10)){
        rectfill(buffer, caseP_x *50, (caseP_y -3)*50, caseP_x *50 +50, (caseP_y -3)*50 +50, makecol(0,255,0));}
        caseP_x--;
    for(int i =0; i <3; i++){
        if(tabChose[caseP_x+i][caseP_y-2] ==0 && caseP_x+i <20 && caseP_y-2 <10){
            rectfill(buffer, (caseP_x +i) *50, (caseP_y -2)*50, (caseP_x +i) *50 +50, (caseP_y -2)*50 +50, makecol(0,255,0));}
        }
    caseP_x--;
    for(int i =0; i <5; i++){
            if(tabChose[caseP_x+i][caseP_y-1] ==0 && caseP_x+i <20 && caseP_y-1<10){
                rectfill(buffer, (caseP_x +i) *50, (caseP_y -1)*50, (caseP_x +i) *50 +50, (caseP_y -1)*50 +50, makecol(0,255,0));}
        }
    caseP_x--;
    for(int i =0; i <7; i++){
            if(tabChose[caseP_x+i][caseP_y] ==0 && caseP_x+i <20 && caseP_y <10){
                rectfill(buffer, (caseP_x +i) *50, (caseP_y)*50, (caseP_x +i) *50 +50, (caseP_y)*50 +50, makecol(0,255,0));}
        }
    caseP_x++;
    for(int i =0; i <5; i++){
            if(tabChose[caseP_x+i][caseP_y+1] ==0 && caseP_x+i <20 && caseP_y+1 <10){
                rectfill(buffer, (caseP_x +i) *50, (caseP_y +1)*50, (caseP_x +i) *50 +50, (caseP_y +1)*50 +50, makecol(0,255,0));}
        }
    caseP_x++;
    for(int i =0; i <3; i++){
            if(tabChose[caseP_x+i][caseP_y+2] ==0 && caseP_x+i <20 && caseP_y+2 <10){
                rectfill(buffer, (caseP_x +i) *50, (caseP_y +2)*50, (caseP_x +i) *50 +50, (caseP_y +2)*50 +50, makecol(0,255,0));}
        }
    caseP_x++;
    if(tabChose[caseP_x][caseP_y+3] ==0 && caseP_x <20 && caseP_y+3 <10){
            rectfill(buffer, caseP_x *50, (caseP_y +3)*50, caseP_x *50 +50, (caseP_y +3)*50 +50, makecol(0,255,0));}
}
