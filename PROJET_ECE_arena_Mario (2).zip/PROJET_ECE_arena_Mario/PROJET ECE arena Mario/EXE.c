#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

        /// ######## DEFINE ######## ///
#define COL 1200
#define LIN 700
#define T_CASE 50

        /// ######## STRUCTURES ######## ///
typedef struct joueur{
    int pv;             //nombre de PV du joueur � savoir 20
    int pa;             //nombre de PA du joueur
    int num_joueur;     //le num�ro du joueur
    int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
    int pos_x;
    int pos_y;
}t_joueur;

///---------------------------------Structure classe---------------------------------///
typedef struct classe{
char nom_de_classe[30];
int tab_degats_attaques[5];     //tableau contenant les d�g�ts inflig�s par les attaques
int tab_PA_attaques[5];         //tableau contenant les c�uts des attaques
}t_classe;




        /// ######## PROTOTYPES ######## ///
int creationPlateau(BITMAP *buffer, BITMAP *padMvmt, int souris_lin, int souris_col, int souris_gauche);
int init();
void affichageZoneVerte(int caseP_x, int caseP_y, int tabChose[20][10], BITMAP *buffer);
void positionSouris(int *souris_lin, int *souris_col, int *souris_gauche);
//void deplacements(int dep, int dep_v2, int souris_gauche, int souris_lin, int souris_col,BITMAP *plateau, BITMAP *cache, BITMAP *buffer, BITMAP *sprite, BITMAP *padMvmt, t_joueur *tableau_joueur, int tabChose[20][10], int tour);
//ini_classe(t_classe *classe);


        /// ######## MAIN ######## ///
int EXE()
{
    srand(time(NULL));
    /// --------------------------- Sprite DEBUT --------------------------- ///
    BITMAP *buffer; // Bitmap double buffer

    BITMAP *stats;

    BITMAP *sprite;
    BITMAP *padMvmt;
    BITMAP *cache;
    BITMAP *FinDeTour;

    BITMAP *mario;
    BITMAP *tabToad[5];
    BITMAP *tabBowser[5];
    BITMAP *tabYoshi[5];

    BITMAP *plateau;

    /// LOAD DES TABLEAUX DE BITMAPS

    init(); // Sous programme d'initialisation d'allegro

    char nomfichier[256];
    /*for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Toad%d.bmp", i);
        tabToad[i] =load_bitmap(nomfichier, NULL);
        if (!tabToad[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }
    for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Bowser%d.bmp", i);
        tabBowser[i] =load_bitmap(nomfichier, NULL);
        if (!tabBowser[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }
    for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Yoshi%d.bmp", i);
        tabYoshi[i] =load_bitmap(nomfichier, NULL);
        if (!tabYoshi[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }*/
        // sprintf permet de faire un printf dans une chaine

        mario =load_bitmap("Mario0.bmp", NULL);
        if (!mario){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}





    //allegro_message("pas pu trouver plato.bmp");
    plateau =load_bitmap("pato.bmp",NULL);
     if(!plateau){
        allegro_message("pas pu trouver plato.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}

    stats =load_bitmap("stats.bmp",NULL);
     if(!stats){
        allegro_message("pas pu trouver stats.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}





    FinDeTour=load_bitmap("FinDeTour.bmp",NULL);
    if (!FinDeTour){
        allegro_message("pas pu trouver findetour.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}
    sprite=load_bitmap("Yoshi0.bmp",NULL); // On charge
    if (!sprite){
        allegro_message("pas pu trouver sprite.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}
    padMvmt=load_bitmap("Pad mouvement.bmp",NULL); // Pareil
    if (!padMvmt){
        allegro_message("pas pu trouver padMvmt.bmp");
        exit(EXIT_FAILURE);}
    buffer =create_bitmap(COL,LIN); // Cr�ation de la bitmap du buffer (vu qu'elle n'est pas charg�e)
    cache =create_bitmap(COL,LIN); // Cr�ation de la bitmap du buffer (vu qu'elle n'est pas charg�e)
    /// --------------------------- Sprite FIN --------------------------- ///

    show_mouse(screen); // Affiche la souris � l'�cran

    //--- Variables Souris ---//
    int souris_lin =0, souris_col =0; // Variables de la position de la souris (varie entre 0 et 20)
    int souris_gauche =0;

    //--- Tableau d'obstacles ---//
    int tabChose[20][10] ={0};

    //--- Variables Tour ---//
    int tour =0;
    int tour_suivant =0;
    int dep =0;
    int dep_v2 =0;
    int nbjoueurs;
    int num_sort =0;

    int menu =1;


    //--- Instanciation Structure ---//
    //t_joueur* tableau_joueur = malloc(nbjoueurs+1 * sizeof(t_joueur));
    //tableau_joueur[tour].pos_x =10;
    //tableau_joueur[tour].pos_y =5;
    t_classe* classe;

                                  ///Menu

    ///        Initialisation des structures
    //initialisation_joueur(nbjoueurs, tableau_joueur); //Initialise les joueurs, n�cessite le nombre de joueurs: "nbjoueurs" et le tableau: "tableau_joueur"




    //(rand() % (Max -Min +1)) +Min;
    /// Positions al�atoires des joueurs

    /// Positions al�atoires des joueurs


  while(menu ==1){ //Boucle du menu

    //nbjoueurs =prog_menu();
    nbjoueurs =3;
    t_joueur* tableau_joueur = malloc(nbjoueurs+1 * sizeof(t_joueur));
    //initialisation_joueur(nbjoueurs, tableau_joueur);
    //ini_classe(classe); //Initialise les classes, n�cessite le tableau: "classe"
    //prog_choix_des_classes(tableau_joueur, nbjoueurs);

    //tableau_joueur[0].pos_x =(rand()% (21));
    //tableau_joueur[0].pos_y =(rand()% (11));

    /*tableau_joueur[1].pos_x =(rand()% (21));
    tableau_joueur[1].pos_y =(rand()% (11));

    tableau_joueur[2].pos_x =(rand()% (21));
    tableau_joueur[2].pos_y =(rand()% (11));

    tableau_joueur[3].pos_x =(rand()% (21));
    tableau_joueur[3].pos_y =(rand()% (11));*/

    //nbjoueurs =prog_menu();                              ///Menu
    //initialisation_joueur(nbjoueurs, tableau_joueur);
   // prog_choix_des_classes(tableau_joueur, nbjoueurs);

    //statistiquesDesClassesAvecPV(tableau_joueur, nbjoueurs);
    tableau_joueur[0].pos_x =9;
    tableau_joueur[0].pos_y =4;



    while(!key[KEY_ESC]){ //Boucle de partie
            //clear_bitmap(buffer);
        tabChose[3][1]=9; tabChose[2][1]=9;
        tabChose[9][2] =9;

        positionSouris(&souris_lin, &souris_col, &souris_gauche); /* Sous programme qui passe par adresse la case de la souris
                                                                     //et si on clique (souris_lin, souris_col, souris_gauche) */
        blit(plateau,buffer, 0,0,0,0, COL, LIN); //On affiche le plateau en premier

        creationPlateau(buffer, padMvmt, souris_lin, souris_col, souris_gauche); //Sous programme de cr�ation du plateau
        deplacements(mario,dep, dep_v2,souris_gauche, souris_lin, souris_col,plateau, cache, buffer, sprite, padMvmt, tableau_joueur, tabChose, tour); //Sous programme de d�placements

        AffichageBouton(buffer);
        ZoneAttaque(buffer, plateau, tableau_joueur); // appeler avant la cr�ation du plateau pour que �a marche ? (� voir)
        //attaque(tour, tabChose, classe, tableau_joueur, num_sort); /// PARAMETRES

        draw_sprite(buffer, sprite, tableau_joueur[tour].pos_x *50, tableau_joueur[tour].pos_y *50 -40);
        //draw_sprite(buffer, mario, tableau_joueur[tour+1].pos_x *50, tableau_joueur[tour+1].pos_y *50 -40);

        blit(stats, buffer, 1000, 300, 1200, 500, COL, LIN);
        draw_sprite(buffer, FinDeTour, 1000, 500);
        blit(buffer,screen, 0,0,0,0, COL, LIN); //On termine par affiche le buffer


        if(souris_gauche ==1 && mouse_x >1002 && mouse_y >500 && mouse_y <700){
            tour++;
        }
        if(tour ==4){
            tour =0;}

    }//FinBouclePartie
  }//FinBoucleMenu


    return 0;
}

        /// ######## SOUS PROGRAMMES ######## ///

void positionSouris(int *souris_lin, int *souris_col, int *souris_gauche){
    *souris_lin =(mouse_y/50); //Recup la position en pixels de la souris et la divise par 50 pour avoir la case
    *souris_col =(mouse_x/50);
    *souris_gauche =mouse_b&1; // Vaut 0 si pas de clique, vaut 1 si
}

int creationPlateau(BITMAP *buffer, BITMAP *padMvmt, int souris_lin, int souris_col, int souris_gauche){
    int ligne =10, colonne =20;

    for(int i =0; i <colonne; i++){
        for(int u =0; u <ligne; u++){
            rect(buffer,i*T_CASE,u*T_CASE,(i+1)*T_CASE,(u+1)*T_CASE, makecol(255,255,255));
        }
    }

    rectfill(buffer, 1050, 0, 1200, 20, makecol(0,0,0));
    textprintf_ex(buffer, font, 1010, 10, makecol(255,255,255), -1, "lin: %d col: %d clic: %d", souris_lin, souris_col, souris_gauche);

    draw_sprite(buffer, padMvmt, 1002, 30);
}

int init(){
    allegro_init();
    install_mouse();
    install_keyboard();

    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED,(COL),(LIN),0,0))!=0){
        allegro_message("Pb de mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);}
}





int ini_classe(t_classe* classe)
{
    classe->tab_degats_attaques[0] = 2;     //Initialisation d�g�ts attaques corps � corps
    classe->tab_degats_attaques[1] = 8;     //Initialisation d�g�ts attaques 1
    classe->tab_degats_attaques[2] = 5;     //Initialisation d�g�ts attaques 2
    classe->tab_degats_attaques[3] = 4;     //Initialisation d�g�ts attaques 3
    classe->tab_degats_attaques[4] = 5;     //Initialisation d�g�ts attaques 4

    classe->tab_PA_attaques[0] = 2;         //Attaques corps � corps
    classe->tab_PA_attaques[1] = 3;         //Attaques n�1
    classe->tab_PA_attaques[2] = 4;         //Attaques n�2
    classe->tab_PA_attaques[3] = 8;         //Attaques n�3
    classe->tab_PA_attaques[4] = 6;         //Attaques n�4
}

///------------------------Sous prog Initialisation des joueurs------------------------///
                    //////////////////////////////////////////////////
                    //      Le sous prog prend en param�tres:       //
                    //          le nombre de joueurs (int)          //
                    //      le tableau de structure tableau_joueur  //
                    //////////////////////////////////////////////////
int initialisation_joueur(int nbjoueurs, t_joueur* tableau_joueur){
    for(int i = 0; i <nbjoueurs; i++)
    {
        tableau_joueur[i].pv = 20;
        tableau_joueur[i].pa = 3;
        tableau_joueur[i].num_joueur = i;
        tableau_joueur[i].classe_joueur = i+1;
        tableau_joueur[i].pos_x = 0;
        tableau_joueur[i].pos_y = 0;
    }
}
