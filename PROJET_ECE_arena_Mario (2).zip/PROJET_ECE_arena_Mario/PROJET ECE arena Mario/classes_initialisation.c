#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

                            /// ######## STRUCTURES ######## ///

///---------------------------------Structure classe---------------------------------///
typedef struct classe{
char nom_de_classe[90];
int tab_degats_attaques[6];     //tableau contenant les d�g�ts inflig�s par les attaques
int tab_PA_attaques[6];         //tableau contenant les c�uts des attaques
}t_classe;

///------------------------Structure joueur------------------------///
typedef struct joueur{
int pv;             //nombre de PV du joueur
int pa;             //nombre de PA du joueur
int num_joueur;     //le num�ro du joueur
int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
int pos_x;          //Position horizontale du joueur
int pos_y;          //Position verticale   du joueur
}t_joueur;




///--------------------Initialisations tableaux d�g�ts et PA attaques--------------------///
                    //////////////////////////////////////////////////
                    //      Le sous prog prend en param�tres:       //
                    //      un �l�ment de la structure t_classe     //
                    //////////////////////////////////////////////////

///----------------------------Fin de la structure classe----------------------------///

///--------------------Initialisations tableaux d�g�ts et PA attaques--------------------///
            //////////////////////////////////////////////////
            //          Le sous prog prend en param�tres:   //
            //        un �l�ment de la structure t_classe   //
            //////////////////////////////////////////////////

