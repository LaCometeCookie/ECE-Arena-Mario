#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

                            /// ######## STRUCTURES ######## ///

///---------------------------------Structure classe---------------------------------///
typedef struct classe{
char nom_de_classe[30];
int tab_degats_attaques[5];     //tableau contenant les d�g�ts inflig�s par les attaques
int tab_PA_attaques[5];         //tableau contenant les c�uts des attaques
}t_classe;

///------------------------Structure joueur------------------------///
typedef struct joueur{
int pv;             //nombre de PV du joueur
int pa;             //nombre de PA du joueur
int num_joueur;     //le num�ro du joueur
int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
int pos_x;          //Position horizontale du joueur
int pos_y;          //Position verticale   du joueur
}t_joueur;




///--------------------Initialisations tableaux d�g�ts et PA attaques--------------------///
                    //////////////////////////////////////////////////
                    //      Le sous prog prend en param�tres:       //
                    //      un �l�ment de la structure t_classe     //
                    //////////////////////////////////////////////////

///----------------------------Fin de la structure classe----------------------------///

///--------------------Initialisations tableaux d�g�ts et PA attaques--------------------///
            //////////////////////////////////////////////////
            //          Le sous prog prend en param�tres:   //
            //        un �l�ment de la structure t_classe   //
            //////////////////////////////////////////////////
int ini_classe(t_classe classe)
{
    classe.tab_degats_attaques[0] = 2;     //Initialisation d�g�ts attaques corps � corps
    classe.tab_degats_attaques[1] = 8;     //Initialisation d�g�ts attaques 1
    classe.tab_degats_attaques[2] = 5;     //Initialisation d�g�ts attaques 2
    classe.tab_degats_attaques[3] = 4;     //Initialisation d�g�ts attaques 3
    classe.tab_degats_attaques[4] = 5;     //Initialisation d�g�ts attaques 4

    classe.tab_PA_attaques[0] = 2;         //Attaques corps � corps
    classe.tab_PA_attaques[1] = 3;         //Attaques n�1
    classe.tab_PA_attaques[2] = 4;         //Attaques n�2
    classe.tab_PA_attaques[3] = 8;         //Attaques n�3
    classe.tab_PA_attaques[4] = 6;         //Attaques n�4
}

///------------------------Sous prog Initialisation des joueurs------------------------///
                    //////////////////////////////////////////////////
                    //      Le sous prog prend en param�tres:       //
                    //          le nombre de joueurs (int)          //
                    //      le tableau de structure tableau_joueur  //
                    //////////////////////////////////////////////////
int initialisation_joueur(int nbjoueurs, t_joueur* tableau_joueur){
    for(int i = 0; i<nbjoueurs; i++)
    {
        tableau_joueur[i].pv = 20;
        tableau_joueur[i].pa = 3;
        tableau_joueur[i].num_joueur = i;
        tableau_joueur[i].classe_joueur = i+1;
        tableau_joueur[i].pos_x = 0;
        tableau_joueur[i].pos_y = 0;
    }
}
