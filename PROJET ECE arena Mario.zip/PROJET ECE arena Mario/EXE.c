#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

        /// ######## DEFINE ######## ///
#define COL 1200
#define LIN 700
#define T_CASE 50

        /// ######## STRUCTURES ######## ///
typedef struct joueur{
    int pv;             //nombre de PV du joueur � savoir 20
    int pa;             //nombre de PA du joueur
    int num_joueur;     //le num�ro du joueur
    int classe_joueur;  //(1: Mario, 2: Bowser, 3: Yoshi, 4: Toad)
    int pos_x;
    int pos_y;
}t_joueur;

typedef struct classe{
char nom_de_classe[30];
int tab_degats_attaques[5];     //tableau contenant les d�g�ts inflig�s par les attaques
int tab_PA_attaques[5];         //tableau contenant les c�uts des attaques
}t_classe;



        /// ######## PROTOTYPES ######## ///
int creationPlateau(BITMAP *buffer, BITMAP *padMvmt, int souris_lin, int souris_col, int souris_gauche);
int init();
void affichageZoneVerte(int caseP_x, int caseP_y, int tabChose[20][10], BITMAP *buffer);
void positionSouris(int *souris_lin, int *souris_col, int *souris_gauche);
void deplacements(int dep, int dep_v2, int souris_gauche, int souris_lin, int souris_col, BITMAP *cache, BITMAP *buffer, BITMAP *sprite, BITMAP *padMvmt, t_joueur *tableau_joueur, int tabChose[20][10], int tour);
ini_classe(t_classe *classe);


        /// ######## MAIN ######## ///
int EXE()
{
    srand(TIME(NULL));
    /// --------------------------- Sprite DEBUT --------------------------- ///
    BITMAP *buffer; // Bitmap double buffer
    BITMAP *sprite;
    BITMAP *padMvmt;
    BITMAP *cache;
    BITMAP *FinDeTour;

    BITMAP *tabMario[5];
    BITMAP *tabToad[5];
    BITMAP *tabBowser[5];
    BITMAP *tabYoshi[5];

    BITMAP *plateau;

    /// LOAD DES TABLEAUX DE BITMAPS
    char nomfichier[256];
    for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Toad%d.bmp", i);
        tabToad[i] =load_bitmap(nomfichier, NULL);
        if (!tabToad[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }
    for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Bowser%d.bmp", i);
        tabBowser[i] =load_bitmap(nomfichier, NULL);
        if (!tabBowser[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }
    for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Mario%d.bmp", i);
        tabMario[i] =load_bitmap(nomfichier, NULL);
        if (!tabMario[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }
    for(int i =0; i <5; i++){
        // sprintf permet de faire un printf dans une chaine
        sprintf(nomfichier, "Yoshi%d.bmp", i);
        tabYoshi[i] =load_bitmap(nomfichier, NULL);
        if (!tabYoshi[i]){
            allegro_message("Pas pu charger %s", nomfichier);
            exit(EXIT_FAILURE);}
    }

    plateau=load_bitmap("plateau.bmp",NULL);
    if (!plateau){
        allegro_message("pas pu trouver plateau.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}


    init(); // Sous programme d'initialisation d'allegro

    FinDeTour=load_bitmap("FinDeTour.bmp",NULL);
    if (!FinDeTour){
        allegro_message("pas pu trouver sprite.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}
    sprite=load_bitmap("sprite test.bmp",NULL); // On charge
    if (!sprite){
        allegro_message("pas pu trouver sprite.bmp"); // On test si bien charg�
        exit(EXIT_FAILURE);}
    padMvmt=load_bitmap("Pad mouvement.bmp",NULL); // Pareil
    if (!padMvmt){
        allegro_message("pas pu trouver padMvmt.bmp");
        exit(EXIT_FAILURE);}
    buffer =create_bitmap(COL,LIN); // Cr�ation de la bitmap du buffer (vu qu'elle n'est pas charg�e)
    cache =create_bitmap(COL,LIN); // Cr�ation de la bitmap du buffer (vu qu'elle n'est pas charg�e)
    /// --------------------------- Sprite FIN --------------------------- ///

    show_mouse(screen); // Affiche la souris � l'�cran

    //--- Variables Souris ---//
    int souris_lin =0, souris_col =0; // Variables de la position de la souris (varie entre 0 et 20)
    int souris_gauche =0;

    //--- Tableau d'obstacles ---//
    int tabChose[20][10] ={0};

    //--- Variables Tour ---//
    int tour =0;
    int tour_suivant =0;
    int dep =0;
    int dep_v2 =0;
    int nbjoueurs;
    int num_sort =0;

    int menu =1;


    //--- Instanciation Structure ---//
    t_joueur* tableau_joueur = malloc(nbjoueurs+1 * sizeof(t_joueur));
    //tableau_joueur[tour].pos_x =10;
    //tableau_joueur[tour].pos_y =5;
    t_classe* classe;

    ///        Initialisation des structures
    //initialisation_joueur(nbjoueurs, tableau_joueur); //Initialise les joueurs, n�cessite le nombre de joueurs: "nbjoueurs" et le tableau: "tableau_joueur"
    initialisation_joueur(nbjoueurs, tableau_joueur);
    ini_classe(classe); //Initialise les classes, n�cessite le tableau: "classe"

    (rand() % (Max -Min +1)) +Min;
    /// Positions al�atoires des joueurs
    tableau_joueur[0].pos_x =(rand()% (21));
    tableau_joueur[0].pos_y =(rand()% (11));

    tableau_joueur[1].pos_x =(rand()% (21));
    tableau_joueur[1].pos_y =(rand()% (11));

    tableau_joueur[2].pos_x =(rand()% (21));
    tableau_joueur[2].pos_y =(rand()% (11));

    tableau_joueur[3].pos_x =(rand()% (21));
    tableau_joueur[3].pos_y =(rand()% (11));
    /// Positions al�atoires des joueurs


  while(menu ==1){ //Boucle du menu

    nbjoueurs =prog_menu();                              ///Menu

    //prog_choix_des_classes(tableau_joueur, nbjoueurs);
    //statistiquesDesClassesAvecPV(tableau_joueur, nbjoueurs);



    while(!key[KEY_ESC]){ //Boucle de partie
        positionSouris(&souris_lin, &souris_col, &souris_gauche); /* Sous programme qui passe par adresse la case de la souris
                                                                     et si on clique (souris_lin, souris_col, souris_gauche) */
        blit(buffer,plateau, 0,0,0,0, COL, LIN); //On affiche le plateau en premier


        creationPlateau(buffer, padMvmt, souris_lin, souris_col, souris_gauche); //Sous programme de cr�ation du plateau
        deplacements(dep, dep_v2,souris_gauche, souris_lin, souris_col, cache, buffer, sprite, padMvmt, tableau_joueur, tabChose, tour); //Sous programme de d�placements

        AffichageBouton(buffer);
        ZoneAttaque(buffer, tableau_joueur); // appeler avant la cr�ation du plateau pour que �a marche ? (� voir)
        //attaque(tour, tabChose, classe, tableau_joueur, num_sort); /// PARAMETRES

        draw_sprite(buffer, FinDeTour, 1000, 500);
        blit(buffer,screen, 0,0,0,0, COL, LIN); //On termine par affiche le buffer


        if(souris_gauche ==1 && mouse_x >1002 && mouse_y >500 && mouse_y <700){
            tour++;
        }
        if(tour ==4){
            tour =0;}

    }//FinBouclePartie
  }//FinBoucleMenu


    return 0;
}

        /// ######## SOUS PROGRAMMES ######## ///

void positionSouris(int *souris_lin, int *souris_col, int *souris_gauche){
    *souris_lin =(mouse_y/50); //Recup la position en pixels de la souris et la divise par 50 pour avoir la case
    *souris_col =(mouse_x/50);
    *souris_gauche =mouse_b&1; // Vaut 0 si pas de clique, vaut 1 si
}

int creationPlateau(BITMAP *buffer, BITMAP *padMvmt, int souris_lin, int souris_col, int souris_gauche){
    int ligne =10, colonne =20;

    for(int i =0; i <colonne; i++){
        for(int u =0; u <ligne; u++){
            rect(buffer,i*T_CASE,u*T_CASE,(i+1)*T_CASE,(u+1)*T_CASE, makecol(255,255,255));
        }
    }

    rectfill(buffer, 1050, 0, 1200, 20, makecol(0,0,0));
    textprintf_ex(buffer, font, 1010, 10, makecol(255,255,255), -1, "lin: %d col: %d clic: %d", souris_lin, souris_col, souris_gauche);

    draw_sprite(buffer, padMvmt, 1002, 30);
}

int init(){
    allegro_init();
    install_mouse();
    install_keyboard();

    set_color_depth(desktop_color_depth());
    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED,(COL),(LIN),0,0))!=0){
        allegro_message("Pb de mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);}
}
